from django.db import models
from unittest.util import _MAX_LENGTH


# Create your models here.
class  Student(models.Model):

    name=models.CharField(max_length = 50)

    roll_num=models.IntegerField(primary_key=True)

   

    school=models.CharField(max_length=50,default="BM PATIL")

class Attendance(models.Model):
    RollNo= models.ForeignKey('Student', on_delete=models.CASCADE, db_column='usn')
    current_attendance = models.IntegerField(null=False, default=0)
    percent = models.IntegerField(null=False, default=0)