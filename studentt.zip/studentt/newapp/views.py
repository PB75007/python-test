from django.shortcuts import render
from .models import Student
from django.contrib.auth.models import User
from django.http import HttpResponse

# Create your views here.
def create(request):

    if request.method == 'POST':

        name = request.POST.get("name")

        rollnum = request.POST.get("rollnum")

        b = Student(name,roll_num=rollnum)

        b.save()

    


def delete(request):

     if request.method == 'POST':

        member = Student.objects.get(roll_num=id)

        member.delete()

        return HttpResponse("deleted")