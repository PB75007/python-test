from emp_mg_sys import views
from django.urls import URLPattern, path

urlpatterns = [
    path('student/',views.create,name="student"),
    path('student/',views.delete,name ="student"),